# Comic Con Game
Authors/developers of game: 

## For KV6002 

# Challenge Task : Challenge 5 - Event Management

### **Details of Game Concept**

<sup>The</sup> game is based on a tycoon top down 2-d environment which allows for the opportunity to teach and educate players and additional users we are catering to, and the audiences seeking to gain skills and acknowlegability - in being able to better handle their own indivdual real world situations. Allowing players to gain useful insight and skills aquired through the multiple implemented systems which come together to bring the core concept of the event managament system.

As a group we have been specific with this concept, to-which we have brought into the world of finance and economics. A game which simulates a economic environment confined by the barriers of developement, The game is specifically within a comic-con hall, (think of a stadium/gymnasium with stands). These stands aquire demand to in-turn sell the items they offer, customers being the single source of income for stall owners brings to light the immersive engagement feedback-loop that players will be attached to when trying to achieve a goal while playing the game while also teaching valuable information users can obtain, we use the feedback loop and incentive for players to play the game as a way to leverage time to give us the ability to feed information to players. 

The game needs players to continually obtain money which with the economics mechanic allows for turn over profits and revenue and losses to which is tracked and presented to each player after the end of each working day, however if the players cant keep customers happy through having a constant stock of demanded items then the players will lose the game. This allows for players to get a sense of organisational skills which comes highly into ADHD managament for example when trying to time manage and organise and plan daily life, which for jobs which attract greater ranges of diversity and uniqueness would be highly valuable and possibly increase real world user productivity. 

---
Neurologically thought has been brought into how players could react though stimuli ..... 

- player accessibility blind etc. 

-----


### [ _Audiences:_ ] 

-
-

----
- ## ENGINE : Unity 
- ## Version : 2022.3.4f1




+ ⚠️REMINDERS DO NOT CHANGE THROUGH TERMINAL PUSH OR COMMIT UNTIL (CHANGE/PUSH) VERIFICATION HAS BEEN SET UP :shipit: ⚠️